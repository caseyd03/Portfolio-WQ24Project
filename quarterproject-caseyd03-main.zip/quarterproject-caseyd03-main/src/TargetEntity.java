public interface TargetEntity extends Entity{
    void decreaseHealth();
    Point getPosition();

}
